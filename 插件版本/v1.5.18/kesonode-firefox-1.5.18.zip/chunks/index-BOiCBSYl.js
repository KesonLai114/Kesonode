import{a as i}from"./puzzle-du14S76K.js";function p(a){return null}const u=["bookmarks","history","sessions","extensions"];function l(a){const o=new Map;for(const t of a){const e=o.get(t.device_id);e?e.push(t):o.set(t.device_id,[t])}return[...o.values()].map(t=>[...t].sort((e,r)=>u.indexOf(e.data_type)-u.indexOf(r.data_type)))}const h=24*60*60*1e3,m=30;function M(a,o,t){if(o||!a)return!1;const e=Date.parse(a);return Number.isNaN(e)?!1:t-e>m*h}function y(a,o,t){const e=Date.parse(a),r=Number.isNaN(e)?0:Math.max(0,Math.floor((o-e)/1e3));if(r<1)return new Intl.RelativeTimeFormat(t,{numeric:"auto"}).format(0,"second");const n=new Intl.RelativeTimeFormat(t,{numeric:"always"});if(r<60)return n.format(-r,"second");const c=Math.floor(r/60);if(c<60)return n.format(-c,"minute");const f=Math.floor(c/60);if(f<24)return n.format(-f,"hour");const s=Math.floor(f/24);return s<60?n.format(-s,"day"):s<365?n.format(-Math.floor(s/30),"month"):n.format(-Math.floor(s/365),"year")}/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=i("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=i("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=i("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=i("Undo2",[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]]);export{k as C,m as D,v as E,x as R,D as U,y as a,l as g,M as i,p as r};
