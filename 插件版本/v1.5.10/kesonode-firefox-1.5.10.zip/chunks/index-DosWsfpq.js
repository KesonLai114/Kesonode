import{a as s}from"./puzzle-DV83tF1_.js";function c(o){return null}const n=["bookmarks","history","sessions","extensions"];function p(o){const a=new Map;for(const e of o){const t=a.get(e.device_id);t?t.push(e):a.set(e.device_id,[e])}return[...a.values()].map(e=>[...e].sort((t,r)=>n.indexOf(t.data_type)-n.indexOf(r.data_type)))}/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=s("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=s("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);export{d as E,h as R,p as g,c as r};
