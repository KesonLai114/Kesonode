import{a as u}from"./puzzle-D6AmjnZl.js";function l(a){return null}const c=["bookmarks","history","sessions","extensions"];function p(a){const r=new Map;for(const t of a){const e=r.get(t.device_id);e?e.push(t):r.set(t.device_id,[t])}return[...r.values()].map(t=>[...t].sort((e,o)=>c.indexOf(e.data_type)-c.indexOf(o.data_type)))}const m=24*60*60*1e3,h=30;function M(a,r,t){if(r||!a)return!1;const e=Date.parse(a);return Number.isNaN(e)?!1:t-e>h*m}function y(a,r,t){const e=Date.parse(a),o=Number.isNaN(e)?0:Math.max(0,Math.floor((r-e)/1e3));if(o<1)return new Intl.RelativeTimeFormat(t,{numeric:"auto"}).format(0,"second");const n=new Intl.RelativeTimeFormat(t,{numeric:"always"});if(o<60)return n.format(-o,"second");const i=Math.floor(o/60);if(i<60)return n.format(-i,"minute");const f=Math.floor(i/60);if(f<24)return n.format(-f,"hour");const s=Math.floor(f/24);return s<60?n.format(-s,"day"):s<365?n.format(-Math.floor(s/30),"month"):n.format(-Math.floor(s/365),"year")}/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=u("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=u("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);export{h as D,v as E,x as R,y as a,p as g,M as i,l as r};
