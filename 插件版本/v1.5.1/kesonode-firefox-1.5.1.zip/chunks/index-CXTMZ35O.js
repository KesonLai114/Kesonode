import{M as s,a}from"./puzzle-mXqm1eI3.js";const c={mmlfiiimnpnjcjhhbldenpcmnibedkfa:{store:s.chrome,url:"https://chromewebstore.google.com/detail/konode/mmlfiiimnpnjcjhhbldenpcmnibedkfa/reviews"},"konabe@proton.me":{store:s.firefox,url:"https://addons.mozilla.org/firefox/addon/konode/"}};function d(t){return c[t]??null}const r=["bookmarks","history","sessions","extensions"];function h(t){const n=new Map;for(const e of t){const o=n.get(e.device_id);o?o.push(e):n.set(e.device_id,[e])}return[...n.values()].map(e=>[...e].sort((o,i)=>r.indexOf(o.data_type)-r.indexOf(i.data_type)))}/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=a("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=a("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=a("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]]);export{f as E,l as R,m as S,h as g,d as r};
